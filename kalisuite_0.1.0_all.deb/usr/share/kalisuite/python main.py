
The script will ensure all Python dependencies are present, then launch the GUI.

## Building and installing the .deb package

A helper script `create_deb_package.py` is provided to package KaliSuite as a Debian package.

### 1. Build the package

