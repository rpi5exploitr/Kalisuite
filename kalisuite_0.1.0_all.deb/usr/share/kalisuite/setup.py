#!/usr/bin/env python3
"""
Setup script for the KaliSuite package.

Defines package metadata, dependencies, and entry point for the console
script `kalisuite` that launches the `main` function in main.py.
"""

from pathlib import Path
from setuptools import setup, find_packages

# Read long description from README.md if it exists
this_dir = Path(__file__).parent
readme_path = this_dir / "README.md"
long_description = readme_path.read_text(encoding="utf-8") if readme_path.is_file() else ""

setup(
    name="kalisuite",
    version="0.1.0",
    author="rpi5exploitr",
    author_email="rpi5exploitr@outlook.com",
    description="GUI for various Kali Linux security tools",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/rpi5exploitr/kalisuite",
    packages=find_packages(),
    include_package_data=True,
    python_requires=">=3.9",
    install_requires=[
        "PyQt6",
        "pymetasploit3",
    ],
    entry_points={
        "console_scripts": [
            "kalisuite=main:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: POSIX :: Linux",
        "Topic :: Security",
        "Framework :: PyQt",
    ],
)
